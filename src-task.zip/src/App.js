// Import the React library for building React components
import React from 'react';

// Import the 'Login' and 'SignUp' components from their respective files
import Login from './login';
import SignUp from './signup';

// Import the CSS file for styling this component
import './App.css';

// Import the 'Authdetails' component from its respective file
import Authdetails from './AuthDetais';

// Define the 'App' function component
function App() {
  return (
    // Render the main container for the entire application with a specific CSS class
    <div className="app-container">
      {/* Create a container for authentication-related components */}
      <div className="auth-container">
        {/* Render the 'SignUp' component */}
        <SignUp />
        
        {/* Render the 'Authdetails' component */}
        <Authdetails />
      </div>
    </div>
  );
}

// Export the 'App' component as the default export
export default App;
