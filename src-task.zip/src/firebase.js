// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAO_Z4t_I-Yudd2cAJDJ--S81Kyb43ZVXw",
    authDomain: "auth-b0b43.firebaseapp.com",
    projectId: "auth-b0b43",
    storageBucket: "auth-b0b43.appspot.com",
    messagingSenderId: "668046782648",
    appId: "1:668046782648:web:8bdc1196f6d02f14f4c44d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app)