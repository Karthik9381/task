// Import the CSS file to apply styles to the component
import './App.css';

// Import the 'createUserWithEmailAndPassword' function from Firebase's authentication module
import { createUserWithEmailAndPassword } from 'firebase/auth';

// Import images for the logo and background
import logo1 from './logo.png';
import back from './back.jpg';

// Import the necessary modules and components from React and Firebase
import React from 'react';
import { auth } from './firebase';
import { useState } from 'react';

// Define the 'SignUp' functional component
const SignUp = () => {
    // Define state variables for email and password using the 'useState' hook
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    // Define the 'signup' function that handles the user registration process
    const signup = (e) => {
        e.preventDefault();
        // Use Firebase's 'createUserWithEmailAndPassword' to create a new user with email and password
        createUserWithEmailAndPassword(auth, email, password)
            .then((userCredentials) => {
                console.log(userCredentials);
            })
            .catch((error) => {
                console.log(error);
            });
    }

    // Render the registration form and UI elements
    return (
        <div className='ts'>
            <div className='left'>
                <img src={logo1} className='logo' alt='' />
            </div>
            <div className='middle'>
                <h1>Create Account</h1>
                <h3>Enter your Credentials to access your account</h3>
                <form onSubmit={signup}>
                    <table>
                        <tr>
                            <td style={{ fontWeight: 'bold', fontFamily: 'sans-serif' }}>Email Address</td>
                        </tr>
                        <tr>
                            <td>
                                {/* Input field for entering email with value and onChange event */}
                                <input
                                    type='text'
                                    className='lines'
                                    name='email'
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder='Enter Your email..'
                                />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ fontWeight: 'bold', fontFamily: 'sans-serif' }}>Password</td>
                        </tr>
                        <tr>
                            <td>
                                {/* Input field for entering password with value and onChange event */}
                                <input
                                    type='password'
                                    className='lines'
                                    name='password'
                                    placeholder='Password'
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ fontWeight: 'bold', fontFamily: 'sans-serif' }}>
                                <input type='checkbox' />
                                Remember for 30 days
                            </td>
                        </tr>
                        <tr style={{ alignContent: 'center' }}>
                            <td>
                                {/* Button for submitting the registration form */}
                                <button type='submit'>Sign Up</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <div className='right'>
                <img src={back} className='back' alt='' />
            </div>
        </div>
    );
}

// Export the 'SignUp' component as the default export
export default SignUp;
