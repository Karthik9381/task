// Import React and necessary hooks from the React library
import React, { useState, useEffect } from 'react';

// Import the 'onAuthStateChanged' function from Firebase's authentication module
import { onAuthStateChanged } from 'firebase/auth';

// Import the 'auth' object from the Firebase configuration file
import { auth } from './firebase';

// Define the 'Authdetails' functional component
const Authdetais = () => {
    // Define a state variable 'authUser' to store the authenticated user
    const [authUser, setAuthUser] = useState(null);

    // Use the 'useEffect' hook to listen for changes in the authentication state
    useEffect(() => {
        // Set up a listener with 'onAuthStateChanged' to track the user's authentication status
        const listen = onAuthStateChanged(auth, (user) => {
            if (user) {
                // If a user is authenticated, set 'authUser' with the user object
                setAuthUser(user);
            } else {
                // If there is no authenticated user, set 'authUser' to null
                setAuthUser(null);
            }
        });
    }, []);

    return (
        <div>
            {/* Render a message based on the authentication state */}
            {authUser ? (
                <p>{`Signed in as ${authUser.email}`}</p>
            ) : (
                <center>
                    <p>Signout</p>
                </center>
            )}
        </div>
    );
}

// Export the 'Authdetais' component as the default export
export default Authdetais;
