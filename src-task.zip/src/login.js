// Import the CSS file to apply styles to the component
import './App.css';

// Import the 'signInWithEmailAndPassword' function from Firebase's authentication module
import { signInWithEmailAndPassword } from 'firebase/auth';

// Import images for the logo and background
import logo1 from './logo.png';
import back from './back.jpg';

// Import the necessary modules and components from React and Firebase
import React from 'react';
import { auth } from './firebase';
import { useState } from 'react';

// Define the 'Login' functional component
const Login = () => {
    // Define state variables for email and password using the 'useState' hook
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    // Define the 'login' function that handles the login process
    const login = (e) => {
        e.preventDefault();
        // Use Firebase's 'signInWithEmailAndPassword' to sign in with email and password
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredentials) => {
                console.log(userCredentials);
            })
            .catch((error) => {
                console.log(error);
            });
    }

    // Render the login form and UI elements
    return (
        <div className='ts'>
            
            <div className='middle'>
                <h1>Welcome back!</h1>
                <h3>Enter your Credentials to access your account</h3>
                <form onSubmit={login}>
                    <table>
                        <tr>
                            <td style={{ fontWeight: 'bold', fontFamily: 'sans-serif' }}>Email Address</td>
                        </tr>
                        <tr>
                            <td>
                                {/* Input field for entering email with value and onChange event */}
                                <input
                                    type='text'
                                    className='lines'
                                    name='email'
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder='Enter Your email..'
                                />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ fontWeight: 'bold', fontFamily: 'sans-serif' }}>Password</td>
                        </tr>
                        <tr>
                            <td>
                                {/* Input field for entering password with value and onChange event */}
                                <input
                                    type='password'
                                    className='lines'
                                    name='password'
                                    placeholder='Password'
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ fontWeight: 'bold', fontFamily: 'sans-serif' }}>
                                <input type='checkbox' />
                                Remember for 30 days
                            </td>
                        </tr>
                        <tr style={{ alignContent: 'center' }}>
                            <td>
                                {/* Button for submitting the login form */}
                                <button type='submit'>Login</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <div className='right'>
                <img src={back} className='back' alt='' />
            </div>
        </div>
    );
}

// Export the 'Login' component as the default export
export default Login;
